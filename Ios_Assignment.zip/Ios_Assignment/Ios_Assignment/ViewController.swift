//
//  ViewController.swift
//  Ios_Assignment
//
//  Created by Gayan Disanayaka on 1/23/21.
//  Copyright © 2021 Gayan Disanayaka. All rights reserved.
//

import UIKit

@IBDesignable class ViewController: UIViewController {

    @IBOutlet weak var apple_View: UIView!
    @IBOutlet weak var face_View: UIView!
    @IBOutlet weak var Google_View: UIView!
    @IBOutlet weak var Email_View: UIView!
    @IBOutlet weak var Main_View: UIView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        //Here I set corner_radius to views on stack-view.
        
        apple_View.layer.cornerRadius = 15
        apple_View.layer.masksToBounds = true
        
        face_View.layer.cornerRadius = 15
        face_View.layer.masksToBounds = true
        
        Google_View.layer.cornerRadius = 15
        Google_View.layer.masksToBounds = true
        
        Email_View.layer.cornerRadius = 15
        Email_View.layer.masksToBounds = true
        
        
        
  

    }
}

